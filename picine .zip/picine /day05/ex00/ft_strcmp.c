/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/16 13:38:34 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/06/21 11:27:00 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<string.h>
#include<stdio.h>
int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while ((s1[i] != '\0' && s2[i] == s1[i])
		|| (s2[i] != '\0' && s2[i] == s1[i]))
	{
		i++;
	}
	return (s1[i] - s2[i]);
}
int main ()
{ int i;
	i=0;
	char s[6] = "houdq";
	char h[6] = "houda";
	 printf("%d \n ",ft_strcmp(s,h));
}

