#include<unistd.h>
#include<stdio.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	l;
	int	f;
	int	i;

	f = 0;
	l = size - 1;
	while (f < l)
	{
		i = tab[f];
		tab[f] = tab[l];
		tab[l] = i;
		l--;
		f++;
	}
}

int main()

{
	int s[] = {1,2,3,4,5,6};

	ft_rev_int_tab(s, 6);
	for (int i=0; i<6; i++)
		printf("%d, ", s[i]);

}
