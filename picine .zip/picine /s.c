#include<stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	c;
	int	i;
	int j;

	i = 0;
	while (i <= size - 1)
	{
		j = i+1;
		while (j <= size - 1)
		{
			if (tab[i] > tab[j])
			{
				c = tab[i];
				tab[i] = tab[j];
				tab [j] = c;
			}
			j++;
		}
		i++;
	}
}

int main()

{
int s[] = {5,6,1,0,-1,3};

ft_sort_int_tab(s, 6);
for(int i=0; i < 6; i++)
	printf("%d, ", s[i]);
}
