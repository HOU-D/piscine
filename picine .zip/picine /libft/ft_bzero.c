/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 11:09:13 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/07 11:09:21 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<string.h>
#include<stdio.h>
void ft_bzero(void *s, size_t n)
{
    unsigned char *p;
    p = (unsigned char*)s;

    while(n > 0)
    {
        *p = '\0';
        p++;
        n = n - 1;
    }
}
int main()
{
    char s[8] ="houdaaa";
    bzero(s,4);
    printf("%s",s);
}

