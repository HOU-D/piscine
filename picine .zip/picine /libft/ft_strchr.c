/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 11:19:30 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/07 11:23:56 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "libft.h"

char *ft_strchr(const char *s, int c)
{
    unsigned int i;
    i = 0;

    while(s[i])
    {
        if(s[i] == (char)c)
            return((char*)s+i);
        i++;
    }
    if(s[i] == (char)c)
        return(NULL);
}
int main()
{
    const char s[] = "Houluda";
    printf("%s",strchr(s, 'u'));
    return(0);
}