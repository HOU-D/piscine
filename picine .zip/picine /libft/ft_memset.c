/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <hoakoumi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 10:21:58 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/18 18:37:26 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*Cette fonction permet de remplir une zone mémoire, identifiée par son adresse et sa taille, avec une valeur précise.*/
#include "libft.h"

void *memset(void *p, int c, size_t len)
{
    unsigned int i;
    unsigned char *h;
    h = (unsigned char*)p;
    i = 0;
    while (i <= len)
    {
        h[i] = (unsigned char)c;
        i++;
    }
    p = (void*)h;
    return(p);
}

/* 
int main()
{
    char s[] = "houda";
    ft_memset( s, 'l', 5 );

    printf("%s",s);

}*/

