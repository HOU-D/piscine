/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*               +++                                 +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 06:54:07 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/08 13:39:47 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isalpha(int c)
{
	if (c <= 'z' && c >= 'a')
		return (1);
	else if (c <= 'Z' && c >= 'A')
		return (1);
	else
		return (0);
}

/* int main()
{
	char a;
	printf("%d",ft_isalpha('a'));
	return 0;
} */ 
