/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <hoakoumi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 11:10:23 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/18 18:38:32 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

 void *ft_memmove(void *dst, const void *src, size_t len)
 {
    unsigned char *sr;
    unsigned char *dest;
    size_t i;
    i = 0;
    dest = (unsigned char *)dst;
    sr = (unsigned char *)src;
    if (dest < sr)
    {
        while(i < len)
        {
            dest[i] = sr[i];
            i++;
        }
    }
    else
    {
        while(i < len)
        {
            dest[len - 1] = sr[len -1];
            len = len - 1; 
        }
    }
    return(dst);
 }
/*int main()
{
    char dest[10];
    char sr[] = "houda";
    printf("%s",memmove(dest,sr,2));
    return(0);
}*/