/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 11:09:42 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/07 11:09:45 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
void *ft_memcpy(void* dst, void const *src, size_t n)
{
    unsigned char *dst1;
    unsigned char *src1;
    dst1 = (unsigned char*)dst;
    src1 = (unsigned char*)src;
    size_t i;
    i = 0;
    while(i < n && src1[i] != '\0')
    {
        dst1[i] = src1[i];
        i++;
    }
    dst=(void*)dst1;
    return(dst);
}

int main()
{
    char dst[4];
    char src[] = "test";
    printf("%s" , ft_memcpy(dst, src, 2));

}





