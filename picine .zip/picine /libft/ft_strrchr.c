/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 11:24:50 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/10/07 11:24:57 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char *ft_strrchr(const char *s, int c)
{
    unsigned int i;
    i = ft_strlen(s);

    while(i >= 0)
    {
        if(s[i] == (char)c)
            return((char*)s+i);
        i--;
    }
    if(s[i] == (char)c)
        return(NULL);
}
int main()
{
    const char s[] = "Houluda";
    printf("%s",ft_strrchr(s, 'u'));
    return(0);
}