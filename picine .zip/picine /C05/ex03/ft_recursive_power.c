/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/28 12:08:57 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/06/28 13:42:30 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int p)
{
	int	r;

	r = nb;
	if (p > 1)
		return (nb * ft_recursive_power(nb, (p - 1)));
	if (p == 0)
		return (1);
	if (p < 0)
		return (0);
	return (r);
}
