#include <stdlib.h>
#include < stdio.h>

int do (char s,
