/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   d.c                                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/30 17:39:30 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/06/30 18:31:13 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"
void h(char o. int n1, int n2)
{
	int r;
	r = 0;

	if ( o  == '+')
		r = n1+n2;
	else if ( o == '-')
		r = n1 -n2;
	else if ( o == '*')
		r = n1 * n2;
	else if ( o == '/')
		r = n1/n2;
	else if ( o == '%')
		 r = n1 % n2 ;
	return (r)
}
intt main ( int ac , char **av)
{
	int a;
	int b;
	int r;

	if ( ac == 4 )
	{
		a = atoi(av[1]);
		b atoi(av[3]);
		r = h(av[2][0],a,b);
		printf("%d",r);
	}
	printf("\n");
	retun 0
}



