/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/14 19:09:20 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/06/18 20:18:12 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
char	*ft_strcpy(char *dest, char *src)
{
	int	i;
	i = 0;
	while(src[i] != '\0')
	{ 
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return dest;
}
int main ()
{
	char  h[] = "houda";
	char v[]= {};
	ft_strcpy(v, h);
	printf("%s",v);		
}

	
