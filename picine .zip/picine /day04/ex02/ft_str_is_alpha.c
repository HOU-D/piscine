/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/18 20:26:23 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/06/19 11:35:12 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int ft_str_is_alpha(char *str)
{
	int i;
	i = 0;
	while (str[i] != '\0')
	{
		if((str[i] >= 'a' && str[i] <= 'z')
				|| (str[i] >= 'A' && str[i] <= 'Z'))
		{	
			i++;
		}

		else
	  	    return(0);
	}
	
	return (1);
}
int main()
{
	char str [] = "hou000000000000";
	printf("%d",ft_str_is_alpha(str));
}
