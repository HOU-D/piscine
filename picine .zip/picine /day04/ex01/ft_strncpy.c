+++/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hoakoumi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/14 19:14:49 by hoakoumi          #+#    #+#             */
/*   Updated: 2022/06/18 20:24:50 by hoakoumi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>
char *ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int i;
	while(src[i] != '\0' && i < n)
	{
		dest[i] = src[i]
		i++;
	}
	dest[i] = '\0';
	return dest ;
}
int main()
{
	char a[] ="houda";
	char v[] = {};
	unsigned int n;
	printf("%s", ft_strncpy(v,a,3));
}

